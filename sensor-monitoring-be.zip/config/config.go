// config/config.go
package config

func Connect() {
	// No database connection needed as we are consuming external API
}
